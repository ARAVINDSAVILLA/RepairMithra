# RepairMithra

A modern home-services homepage (Urban Company–style) with a React 19 + Vite frontend
and an Express + MySQL backend.

## Folder structure

```
repairmithra/
├── frontend/
│   ├── src/
│   │   ├── components/
│   │   │   ├── common/     → Button, Card, SectionHeading, Skeleton (reusable UI)
│   │   │   ├── layout/     → Navbar, Footer
│   │   │   └── home/       → Hero, CategoryGrid, HowItWorks, Testimonials, etc.
│   │   ├── layouts/        → MainLayout (Navbar + Outlet + Footer)
│   │   ├── pages/          → Home.jsx (composes sections, lazy-loads below-the-fold)
│   │   ├── hooks/          → useFetch, useOnScreen
│   │   ├── services/       → api.js (Axios client + endpoint functions)
│   │   ├── utils/          → constants.js (nav links, categories, copy)
│   │   └── styles/         → index.css (Tailwind + design tokens)
│   └── ...
└── backend/
    ├── routes/, controllers/, config/
    ├── server.js
    └── schema.sql           → MySQL tables + seed data
```

## Run the frontend

```bash
cd frontend
npm install
cp .env.example .env
npm run dev
```

Opens on http://localhost:5173. The homepage works fully on local sample data
even before the backend is running (see `fallbackData` in `useFetch`).

## Run the backend

```bash
cd backend
npm install
cp .env.example .env   # fill in your MySQL credentials
mysql -u root -p < schema.sql
npm run dev
```

API runs on http://localhost:5000. Endpoints:

- `GET /api/services` — service categories
- `GET /api/testimonials` — customer reviews
- `POST /api/bookings` — create a booking `{ serviceId, customerName, phone, address, scheduledFor }`

## Design tokens

- **Colors:** Ink `#16213E` (primary/dark), Marigold `#F4A623` (accent/CTA), Paper `#FAF9F6` (background), Trust green `#1F9D6F` (verification/success), Slate `#5C6478` (secondary text)
- **Type:** Sora (display/headings), Inter (body)
- **Radius/shadow:** rounded-xl2 cards with soft, layered shadows that deepen on hover
