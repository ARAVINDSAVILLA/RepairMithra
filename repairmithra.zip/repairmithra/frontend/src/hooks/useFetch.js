import { useEffect, useState, useCallback } from "react";

/**
 * Generic fetch hook — runs an async fetcher fn and tracks
 * loading / error / data state. Falls back to `fallbackData`
 * (e.g. local constants) if the request fails, so the UI never
 * shows a broken homepage while the backend is unavailable.
 */
export default function useFetch(fetcher, { fallbackData = null, deps = [] } = {}) {
  const [data, setData] = useState(fallbackData);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState(null);

  const run = useCallback(() => {
    let cancelled = false;
    setIsLoading(true);
    setError(null);

    fetcher()
      .then((result) => {
        if (!cancelled) setData(result);
      })
      .catch((err) => {
        if (!cancelled) {
          setError(err);
          if (fallbackData !== null) setData(fallbackData);
        }
      })
      .finally(() => {
        if (!cancelled) setIsLoading(false);
      });

    return () => {
      cancelled = true;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, deps);

  useEffect(() => run(), [run]);

  return { data, isLoading, error, refetch: run };
}
