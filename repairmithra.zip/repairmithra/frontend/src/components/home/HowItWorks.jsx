import { motion } from "framer-motion";
import * as LucideIcons from "lucide-react";
import SectionHeading from "../common/SectionHeading.jsx";
import { HOW_IT_WORKS_STEPS } from "../../utils/constants.js";

export default function HowItWorks() {
  return (
    <section id="how-it-works" className="section-padding bg-ink text-white">
      <div className="container-app">
        <SectionHeading
          eyebrow="How it works"
          title="Booked to fixed, in four simple steps"
          description="No haggling on-site, no vanishing technicians. Just a clear path from problem to done."
          className="[&_h2]:text-white [&_p]:text-white/60"
        />

        <div className="mt-12 grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
          {HOW_IT_WORKS_STEPS.map((step, i) => {
            const Icon = LucideIcons[step.icon] || LucideIcons.Check;
            return (
              <motion.div
                key={step.title}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, amount: 0.3 }}
                transition={{ duration: 0.45, delay: i * 0.1, ease: "easeOut" }}
                className="relative rounded-xl2 border border-white/10 bg-white/[0.04] p-6"
              >
                <span className="font-display text-xs font-semibold text-marigold">Step {i + 1}</span>
                <div className="mt-3 grid h-11 w-11 place-items-center rounded-full bg-white/10">
                  <Icon size={20} className="text-marigold" />
                </div>
                <h3 className="mt-4 font-display text-base font-semibold text-white">{step.title}</h3>
                <p className="mt-2 text-sm leading-relaxed text-white/60">{step.description}</p>
              </motion.div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
