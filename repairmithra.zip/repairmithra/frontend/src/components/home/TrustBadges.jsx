import { motion } from "framer-motion";
import { ShieldCheck, BadgeCheck, Clock, IndianRupee } from "lucide-react";

const BADGES = [
  { icon: ShieldCheck, title: "Background-checked", text: "Every technician passes ID and address verification." },
  { icon: BadgeCheck, title: "Skill-tested", text: "Rated on real jobs — only the top-rated stay listed." },
  { icon: Clock, title: "On-time, or discounted", text: "Late arrivals get an automatic service credit." },
  { icon: IndianRupee, title: "Upfront pricing", text: "See the estimate before you confirm, no hidden fees." },
];

export default function TrustBadges() {
  return (
    <section className="section-padding bg-white">
      <div className="container-app grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
        {BADGES.map((badge, i) => (
          <motion.div
            key={badge.title}
            initial={{ opacity: 0, y: 16 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, amount: 0.4 }}
            transition={{ duration: 0.4, delay: i * 0.08, ease: "easeOut" }}
            className="flex gap-4"
          >
            <div className="grid h-12 w-12 shrink-0 place-items-center rounded-2xl bg-trust/10 text-trust">
              <badge.icon size={22} />
            </div>
            <div>
              <h3 className="font-display text-[15px] font-semibold text-ink">{badge.title}</h3>
              <p className="mt-1 text-sm leading-relaxed text-slate">{badge.text}</p>
            </div>
          </motion.div>
        ))}
      </div>
    </section>
  );
}
