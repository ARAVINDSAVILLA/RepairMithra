import { motion } from "framer-motion";
import * as LucideIcons from "lucide-react";
import Card from "../common/Card.jsx";
import SectionHeading from "../common/SectionHeading.jsx";
import { ServiceCardSkeleton } from "../common/Skeleton.jsx";
import useFetch from "../../hooks/useFetch.js";
import { fetchServices } from "../../services/api.js";
import { SERVICE_CATEGORIES } from "../../utils/constants.js";

export default function CategoryGrid() {
  const { data: services, isLoading } = useFetch(fetchServices, {
    fallbackData: SERVICE_CATEGORIES,
    deps: [],
  });

  return (
    <section id="services" className="section-padding">
      <div className="container-app">
        <SectionHeading
          eyebrow="What we fix"
          title="Every home service, one trusted app"
          description="From a flickering light to a full deep-clean — pick a category and see verified pros near you."
        />

        <div className="mt-10 grid grid-cols-2 gap-4 sm:grid-cols-3 sm:gap-5 lg:grid-cols-4">
          {isLoading
            ? Array.from({ length: 8 }).map((_, i) => <ServiceCardSkeleton key={i} />)
            : services.map((service, i) => {
                const Icon = LucideIcons[service.icon] || LucideIcons.Wrench;
                return (
                  <motion.div
                    key={service.id}
                    initial={{ opacity: 0, y: 16 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    viewport={{ once: true, amount: 0.3 }}
                    transition={{ duration: 0.4, delay: (i % 4) * 0.06, ease: "easeOut" }}
                  >
                    <Card as="button" className="group w-full p-5 text-left">
                      <div className="grid h-12 w-12 place-items-center rounded-2xl bg-marigold/15 text-marigold-dark transition-colors group-hover:bg-marigold group-hover:text-ink">
                        <Icon size={22} />
                      </div>
                      <h3 className="mt-4 font-display text-[15px] font-semibold text-ink">{service.name}</h3>
                      <p className="mt-1 text-xs text-slate">{service.jobs}</p>
                      <p className="mt-2 text-xs font-semibold text-trust">{service.price}</p>
                    </Card>
                  </motion.div>
                );
              })}
        </div>
      </div>
    </section>
  );
}
