import { motion } from "framer-motion";
import { Apple, PlayCircle } from "lucide-react";
import Button from "../common/Button.jsx";

export default function AppDownloadCTA() {
  return (
    <section id="partner" className="section-padding">
      <div className="container-app">
        <motion.div
          initial={{ opacity: 0, y: 24 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, amount: 0.3 }}
          transition={{ duration: 0.55, ease: "easeOut" }}
          className="relative overflow-hidden rounded-xl2 bg-ink px-6 py-14 text-center sm:px-16"
        >
          <div className="pointer-events-none absolute -right-16 -top-16 h-56 w-56 animate-float rounded-full bg-marigold/20 blur-3xl" />
          <span className="eyebrow text-marigold">Get the app</span>
          <h2 className="mx-auto mt-3 max-w-xl font-display text-3xl font-bold text-white sm:text-4xl">
            Book faster, track live, right from your pocket
          </h2>
          <p className="mx-auto mt-4 max-w-md text-sm text-white/60 sm:text-base">
            Get exclusive app-only pricing and instant notifications when your technician is on the way.
          </p>
          <div className="mt-8 flex flex-col items-center justify-center gap-3 sm:flex-row">
            <Button variant="primary" icon={Apple} iconPosition="left" as="a" href="#">
              App Store
            </Button>
            <Button variant="outline" icon={PlayCircle} iconPosition="left" as="a" href="#" className="border-white/20 text-white hover:bg-white hover:text-ink">
              Google Play
            </Button>
          </div>
        </motion.div>
      </div>
    </section>
  );
}
