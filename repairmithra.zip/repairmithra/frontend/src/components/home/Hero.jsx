import { useEffect, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Search, CheckCircle2, Circle, Star } from "lucide-react";
import Button from "../common/Button.jsx";
import { BOOKING_STAGES } from "../../utils/constants.js";

/**
 * Signature hero element: a live-tracking booking card that cycles
 * through the actual RepairMithra service flow (request → assigned
 * → on the way → done). This is the one concrete, characteristic
 * thing in the product's world — not a generic stat block.
 */
function BookingStatusCard() {
  const [activeStage, setActiveStage] = useState(0);

  useEffect(() => {
    const interval = setInterval(() => {
      setActiveStage((prev) => (prev + 1) % BOOKING_STAGES.length);
    }, 2200);
    return () => clearInterval(interval);
  }, []);

  return (
    <motion.div
      initial={{ opacity: 0, x: 24 }}
      animate={{ opacity: 1, x: 0 }}
      transition={{ duration: 0.6, ease: "easeOut", delay: 0.2 }}
      className="relative w-full max-w-sm rounded-xl2 bg-white p-6 shadow-card-hover"
    >
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="grid h-11 w-11 place-items-center rounded-full bg-ink text-marigold font-display font-bold">
            SK
          </div>
          <div>
            <p className="font-display text-sm font-semibold text-ink">Suresh Kumar</p>
            <p className="text-xs text-slate">Electrician · 4.9 <Star size={10} className="mb-0.5 inline fill-marigold text-marigold" /></p>
          </div>
        </div>
        <span className="rounded-full bg-trust/10 px-3 py-1 text-xs font-semibold text-trust">Live</span>
      </div>

      <div className="mt-6 space-y-4">
        {BOOKING_STAGES.map((stage, i) => (
          <div key={stage} className="flex items-center gap-3">
            {i <= activeStage ? (
              <CheckCircle2 size={18} className="shrink-0 text-trust" />
            ) : (
              <Circle size={18} className="shrink-0 text-ink/20" />
            )}
            <span
              className={`text-sm transition-colors ${
                i <= activeStage ? "font-medium text-ink" : "text-ink/40"
              }`}
            >
              {stage}
            </span>
            {i === activeStage && (
              <AnimatePresence>
                <motion.span
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  className="ml-auto h-1.5 w-1.5 animate-pulse-ring rounded-full bg-marigold"
                />
              </AnimatePresence>
            )}
          </div>
        ))}
      </div>

      <div className="mt-6 rounded-xl bg-paper p-3 text-xs text-slate">
        Fixing: <span className="font-medium text-ink">Kitchen wiring short-circuit</span> · ETA 12 mins
      </div>
    </motion.div>
  );
}

export default function Hero() {
  return (
    <section className="relative overflow-hidden">
      <div className="pointer-events-none absolute -right-24 -top-24 h-72 w-72 rounded-full bg-marigold/20 blur-3xl" />
      <div className="pointer-events-none absolute -left-32 top-40 h-72 w-72 rounded-full bg-trust/10 blur-3xl" />

      <div className="container-app relative grid gap-12 pb-16 pt-12 md:pb-24 md:pt-16 lg:grid-cols-2 lg:items-center lg:pt-20">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, ease: "easeOut" }}
        >
          <span className="eyebrow">Verified pros · Same-day slots</span>
          <h1 className="mt-4 font-display text-4xl font-extrabold leading-[1.08] text-ink sm:text-5xl lg:text-[3.4rem]">
            Home repairs, handled like a friend would.
          </h1>
          <p className="mt-5 max-w-lg text-base leading-relaxed text-slate sm:text-lg">
            Book an electrician, plumber or technician in under a minute. Track them on a live map,
            pay only when the job's done — no call-backs, no guesswork.
          </p>

          <div className="mt-8 flex flex-col gap-3 sm:flex-row sm:items-center">
            <div className="flex flex-1 items-center gap-3 rounded-full border border-ink/10 bg-white px-5 py-3.5 shadow-card">
              <Search size={18} className="shrink-0 text-slate" />
              <input
                type="text"
                placeholder="What needs fixing? Try 'AC not cooling'"
                className="w-full bg-transparent text-sm text-ink placeholder:text-slate/70 focus:outline-none"
              />
            </div>
            <Button variant="primary" size="lg" className="shrink-0">
              Find a pro
            </Button>
          </div>

          <div className="mt-8 flex items-center gap-6">
            <div className="flex -space-x-3">
              {["A", "B", "C", "D"].map((letter) => (
                <div
                  key={letter}
                  className="grid h-9 w-9 place-items-center rounded-full border-2 border-paper bg-ink-light text-xs font-semibold text-white"
                >
                  {letter}
                </div>
              ))}
            </div>
            <p className="text-sm text-slate">
              <span className="font-semibold text-ink">480,000+</span> homes served across 42 cities
            </p>
          </div>
        </motion.div>

        <div className="flex justify-center lg:justify-end">
          <BookingStatusCard />
        </div>
      </div>
    </section>
  );
}
