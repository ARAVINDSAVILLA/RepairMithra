import { Swiper, SwiperSlide } from "swiper/react";
import { Autoplay, Pagination } from "swiper/modules";
import { Star, Quote } from "lucide-react";
import "swiper/css";
import "swiper/css/pagination";
import Card from "../common/Card.jsx";
import SectionHeading from "../common/SectionHeading.jsx";
import { TestimonialCardSkeleton } from "../common/Skeleton.jsx";
import useFetch from "../../hooks/useFetch.js";
import { fetchTestimonials } from "../../services/api.js";
import { TESTIMONIALS } from "../../utils/constants.js";

export default function Testimonials() {
  const { data: reviews, isLoading } = useFetch(fetchTestimonials, {
    fallbackData: TESTIMONIALS,
    deps: [],
  });

  return (
    <section id="reviews" className="section-padding">
      <div className="container-app">
        <SectionHeading
          eyebrow="Trusted by neighbours like you"
          title="Real homes, real fixes"
          align="center"
        />

        <div className="mt-10">
          {isLoading ? (
            <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
              {Array.from({ length: 3 }).map((_, i) => (
                <TestimonialCardSkeleton key={i} />
              ))}
            </div>
          ) : (
            <Swiper
              modules={[Autoplay, Pagination]}
              spaceBetween={20}
              slidesPerView={1}
              pagination={{ clickable: true }}
              autoplay={{ delay: 4500, disableOnInteraction: false }}
              breakpoints={{
                640: { slidesPerView: 2 },
                1024: { slidesPerView: 3 },
              }}
              className="!pb-12"
            >
              {reviews.map((review) => (
                <SwiperSlide key={review.name}>
                  <Card hoverable={false} className="flex h-full flex-col p-6">
                    <Quote size={26} className="text-marigold/40" />
                    <div className="mt-3 flex gap-0.5">
                      {Array.from({ length: 5 }).map((_, i) => (
                        <Star
                          key={i}
                          size={14}
                          className={i < review.rating ? "fill-marigold text-marigold" : "text-ink/15"}
                        />
                      ))}
                    </div>
                    <p className="mt-3 flex-1 text-sm leading-relaxed text-ink/80">{review.text}</p>
                    <div className="mt-5 flex items-center gap-3 border-t border-ink/5 pt-4">
                      <div className="grid h-10 w-10 place-items-center rounded-full bg-ink text-sm font-semibold text-marigold">
                        {review.name.charAt(0)}
                      </div>
                      <div>
                        <p className="font-display text-sm font-semibold text-ink">{review.name}</p>
                        <p className="text-xs text-slate">{review.location}</p>
                      </div>
                    </div>
                  </Card>
                </SwiperSlide>
              ))}
            </Swiper>
          )}
        </div>
      </div>
    </section>
  );
}
