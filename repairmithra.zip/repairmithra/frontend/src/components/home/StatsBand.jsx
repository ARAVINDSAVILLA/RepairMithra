import { useEffect, useState } from "react";
import useOnScreen from "../../hooks/useOnScreen.js";
import { TRUST_STATS } from "../../utils/constants.js";

function CountUpValue({ value, suffix, isVisible }) {
  const [display, setDisplay] = useState(0);
  const isDecimal = !Number.isInteger(value);

  useEffect(() => {
    if (!isVisible) return;
    const duration = 1400;
    const start = performance.now();

    const step = (now) => {
      const progress = Math.min((now - start) / duration, 1);
      const eased = 1 - Math.pow(1 - progress, 3);
      setDisplay(value * eased);
      if (progress < 1) requestAnimationFrame(step);
    };
    requestAnimationFrame(step);
  }, [isVisible, value]);

  return (
    <span className="font-display text-3xl font-extrabold text-ink sm:text-4xl">
      {isDecimal ? display.toFixed(1) : Math.round(display).toLocaleString("en-IN")}
      {suffix}
    </span>
  );
}

export default function StatsBand() {
  const [ref, isVisible] = useOnScreen({ threshold: 0.4 });

  return (
    <section ref={ref} className="border-y border-ink/10 bg-white">
      <div className="container-app grid grid-cols-2 gap-8 py-12 sm:grid-cols-4">
        {TRUST_STATS.map((stat) => (
          <div key={stat.label} className="text-center">
            <CountUpValue value={stat.value} suffix={stat.suffix} isVisible={isVisible} />
            <p className="mt-1 text-xs font-medium uppercase tracking-wide text-slate sm:text-sm">{stat.label}</p>
          </div>
        ))}
      </div>
    </section>
  );
}
