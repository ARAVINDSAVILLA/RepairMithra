/** Base skeleton block — shimmering placeholder rectangle. */
export function SkeletonBlock({ className = "" }) {
  return <div className={`skeleton rounded-lg ${className}`} />;
}

/** Placeholder for a service category card while data loads. */
export function ServiceCardSkeleton() {
  return (
    <div className="rounded-xl2 bg-white p-5 shadow-card">
      <SkeletonBlock className="h-12 w-12 rounded-2xl" />
      <SkeletonBlock className="mt-4 h-4 w-3/4" />
      <SkeletonBlock className="mt-2 h-3 w-1/2" />
    </div>
  );
}

/** Placeholder for a testimonial card while data loads. */
export function TestimonialCardSkeleton() {
  return (
    <div className="rounded-xl2 bg-white p-6 shadow-card">
      <div className="flex items-center gap-3">
        <SkeletonBlock className="h-11 w-11 rounded-full" />
        <div className="flex-1">
          <SkeletonBlock className="h-3.5 w-2/5" />
          <SkeletonBlock className="mt-2 h-3 w-1/3" />
        </div>
      </div>
      <SkeletonBlock className="mt-5 h-3 w-full" />
      <SkeletonBlock className="mt-2 h-3 w-5/6" />
      <SkeletonBlock className="mt-2 h-3 w-2/3" />
    </div>
  );
}
