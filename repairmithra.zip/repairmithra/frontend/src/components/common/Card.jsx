/**
 * Reusable rounded, shadowed card shell. `hoverable` adds the
 * lift + shadow-grow micro-interaction used across the homepage.
 */
export default function Card({ children, hoverable = true, className = "", as: Component = "div", ...rest }) {
  return (
    <Component
      className={`rounded-xl2 bg-white shadow-card ${
        hoverable ? "transition-all duration-300 hover:-translate-y-1.5 hover:shadow-card-hover" : ""
      } ${className}`}
      {...rest}
    >
      {children}
    </Component>
  );
}
