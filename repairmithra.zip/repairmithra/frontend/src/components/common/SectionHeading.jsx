import { motion } from "framer-motion";

/**
 * Consistent section header: eyebrow label + heading + optional
 * supporting copy, with a shared reveal animation.
 */
export default function SectionHeading({ eyebrow, title, description, align = "left", className = "" }) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 16 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, amount: 0.4 }}
      transition={{ duration: 0.5, ease: "easeOut" }}
      className={`max-w-2xl ${align === "center" ? "mx-auto text-center" : ""} ${className}`}
    >
      {eyebrow && <span className="eyebrow">{eyebrow}</span>}
      <h2 className="mt-3 font-display text-3xl font-bold leading-tight text-ink sm:text-4xl">{title}</h2>
      {description && <p className="mt-4 text-base leading-relaxed text-slate sm:text-lg">{description}</p>}
    </motion.div>
  );
}
