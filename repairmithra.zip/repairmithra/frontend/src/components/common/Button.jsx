import { forwardRef } from "react";

const VARIANT_CLASSES = {
  primary:
    "bg-marigold text-ink hover:bg-marigold-dark shadow-card hover:shadow-card-hover",
  dark:
    "bg-ink text-white hover:bg-ink-light shadow-card hover:shadow-card-hover",
  outline:
    "border-2 border-ink/15 text-ink hover:border-ink hover:bg-ink hover:text-white",
  ghost: "text-ink hover:bg-ink/5",
};

const SIZE_CLASSES = {
  sm: "px-4 py-2 text-sm",
  md: "px-6 py-3 text-[15px]",
  lg: "px-8 py-4 text-base",
};

/**
 * Reusable Button — supports button or anchor rendering, icon
 * slots, and a small set of brand variants/sizes so styling
 * never has to be re-implemented per section.
 */
const Button = forwardRef(function Button(
  {
    as = "button",
    variant = "primary",
    size = "md",
    icon: Icon,
    iconPosition = "right",
    className = "",
    children,
    ...rest
  },
  ref
) {
  const Component = as;
  const classes = `inline-flex items-center justify-center gap-2 rounded-full font-display font-semibold transition-all duration-200 active:scale-[0.97] disabled:opacity-50 disabled:pointer-events-none ${VARIANT_CLASSES[variant]} ${SIZE_CLASSES[size]} ${className}`;

  return (
    <Component ref={ref} className={classes} {...rest}>
      {Icon && iconPosition === "left" && <Icon size={18} aria-hidden="true" />}
      {children}
      {Icon && iconPosition === "right" && <Icon size={18} aria-hidden="true" />}
    </Component>
  );
});

export default Button;
