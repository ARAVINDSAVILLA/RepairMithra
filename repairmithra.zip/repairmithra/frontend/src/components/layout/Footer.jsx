import { Facebook, Instagram, Twitter, Youtube } from "lucide-react";

const FOOTER_COLUMNS = [
  {
    title: "Services",
    links: ["Electrician", "Plumbing", "AC Repair", "Home Cleaning", "Carpentry"],
  },
  {
    title: "Company",
    links: ["About us", "Careers", "Press", "Blog"],
  },
  {
    title: "Support",
    links: ["Help centre", "Safety", "Cancellation policy", "Contact us"],
  },
];

export default function Footer() {
  return (
    <footer className="bg-ink text-white/80">
      <div className="container-app grid gap-12 py-16 md:grid-cols-2 lg:grid-cols-5">
        <div className="lg:col-span-2">
          <div className="flex items-center gap-2">
            <span className="flex h-9 w-9 items-center justify-center rounded-xl bg-marigold font-display text-lg font-bold text-ink">
              R
            </span>
            <span className="font-display text-xl font-bold text-white">RepairMithra</span>
          </div>
          <p className="mt-4 max-w-xs text-sm leading-relaxed text-white/60">
            Verified home service professionals, booked in minutes and tracked until the job is done.
          </p>
          <div className="mt-6 flex gap-3">
            {[Facebook, Instagram, Twitter, Youtube].map((Icon, i) => (
              <a
                key={i}
                href="#"
                aria-label="Social link"
                className="grid h-9 w-9 place-items-center rounded-full bg-white/10 transition-colors hover:bg-marigold hover:text-ink"
              >
                <Icon size={16} />
              </a>
            ))}
          </div>
        </div>

        {FOOTER_COLUMNS.map((col) => (
          <div key={col.title}>
            <h4 className="font-display text-sm font-semibold uppercase tracking-wide text-white">{col.title}</h4>
            <ul className="mt-4 space-y-3">
              {col.links.map((link) => (
                <li key={link}>
                  <a href="#" className="text-sm text-white/60 transition-colors hover:text-marigold">
                    {link}
                  </a>
                </li>
              ))}
            </ul>
          </div>
        ))}
      </div>

      <div className="border-t border-white/10">
        <div className="container-app flex flex-col items-center justify-between gap-3 py-6 text-xs text-white/50 sm:flex-row">
          <p>© {new Date().getFullYear()} RepairMithra. All rights reserved.</p>
          <div className="flex gap-5">
            <a href="#" className="hover:text-white/80">
              Privacy policy
            </a>
            <a href="#" className="hover:text-white/80">
              Terms of service
            </a>
          </div>
        </div>
      </div>
    </footer>
  );
}
