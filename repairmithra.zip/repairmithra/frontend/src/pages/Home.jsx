import { lazy, Suspense } from "react";
import Hero from "../components/home/Hero.jsx";
import CategoryGrid from "../components/home/CategoryGrid.jsx";
import StatsBand from "../components/home/StatsBand.jsx";

// Below-the-fold sections are code-split so the initial bundle
// only ships what's needed for the first paint.
const HowItWorks = lazy(() => import("../components/home/HowItWorks.jsx"));
const TrustBadges = lazy(() => import("../components/home/TrustBadges.jsx"));
const Testimonials = lazy(() => import("../components/home/Testimonials.jsx"));
const AppDownloadCTA = lazy(() => import("../components/home/AppDownloadCTA.jsx"));

function SectionFallback() {
  return (
    <div className="container-app py-16">
      <div className="skeleton h-64 w-full rounded-xl2" />
    </div>
  );
}

export default function Home() {
  return (
    <>
      <Hero />
      <CategoryGrid />
      <StatsBand />
      <Suspense fallback={<SectionFallback />}>
        <HowItWorks />
      </Suspense>
      <Suspense fallback={<SectionFallback />}>
        <TrustBadges />
      </Suspense>
      <Suspense fallback={<SectionFallback />}>
        <Testimonials />
      </Suspense>
      <Suspense fallback={<SectionFallback />}>
        <AppDownloadCTA />
      </Suspense>
    </>
  );
}
