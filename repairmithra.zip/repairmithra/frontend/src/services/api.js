import axios from "axios";

export const apiClient = axios.create({
  baseURL: import.meta.env.VITE_API_BASE_URL || "/api",
  timeout: 10000,
  headers: { "Content-Type": "application/json" },
});

// GET /api/services — list of service categories with live pricing/availability
export const fetchServices = () => apiClient.get("/services").then((res) => res.data);

// GET /api/testimonials — recent customer reviews
export const fetchTestimonials = () => apiClient.get("/testimonials").then((res) => res.data);

// POST /api/bookings — create a new service booking
export const createBooking = (payload) => apiClient.post("/bookings", payload).then((res) => res.data);
