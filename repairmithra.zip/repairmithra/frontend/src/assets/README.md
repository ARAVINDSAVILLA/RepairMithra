This folder holds static assets (logo, favicon, illustrations). Not required for the homepage to run — all icons come from lucide-react / react-icons.
