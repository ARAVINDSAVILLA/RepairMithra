export const NAV_LINKS = [
  { label: "Services", href: "#services" },
  { label: "How it works", href: "#how-it-works" },
  { label: "Reviews", href: "#reviews" },
  { label: "Become a partner", href: "#partner" },
];

export const BOOKING_STAGES = [
  "Request received",
  "Technician assigned",
  "On the way",
  "Job done",
];

export const SERVICE_CATEGORIES = [
  { id: "electrician", name: "Electrician", icon: "Zap", jobs: "38k+ jobs done", price: "From ₹149" },
  { id: "plumber", name: "Plumbing", icon: "Wrench", jobs: "52k+ jobs done", price: "From ₹179" },
  { id: "ac-repair", name: "AC Repair & Service", icon: "Wind", jobs: "26k+ jobs done", price: "From ₹499" },
  { id: "cleaning", name: "Home Cleaning", icon: "Sparkles", jobs: "44k+ jobs done", price: "From ₹399" },
  { id: "carpenter", name: "Carpentry", icon: "Hammer", jobs: "19k+ jobs done", price: "From ₹199" },
  { id: "painting", name: "Painting", icon: "PaintRoller", jobs: "12k+ jobs done", price: "From ₹15/sqft" },
  { id: "appliance", name: "Appliance Repair", icon: "Refrigerator", jobs: "31k+ jobs done", price: "From ₹249" },
  { id: "pest-control", name: "Pest Control", icon: "Bug", jobs: "9k+ jobs done", price: "From ₹599" },
];

export const HOW_IT_WORKS_STEPS = [
  {
    title: "Tell us the problem",
    description: "Pick a service, describe the issue, and choose a slot that works for you — takes under a minute.",
    icon: "MessageSquareText",
  },
  {
    title: "We match a verified pro",
    description: "Every technician is background-checked, trained, and rated by your neighbours.",
    icon: "ShieldCheck",
  },
  {
    title: "Track them in real time",
    description: "See exactly when your technician is assigned, on the way, and at your door.",
    icon: "MapPin",
  },
  {
    title: "Pay only when it's fixed",
    description: "Transparent, upfront pricing. No surprise charges after the job is done.",
    icon: "IndianRupee",
  },
];

export const TESTIMONIALS = [
  {
    name: "Ananya Rao",
    location: "Whitefield, Bengaluru",
    rating: 5,
    text: "Booked an AC service at 9pm and someone was at my door by 10am the next day. Genuinely the least stressful home repair I've had.",
  },
  {
    name: "Vikram Sethi",
    location: "Andheri, Mumbai",
    rating: 5,
    text: "The live tracking is what sold me — I could see the electrician was 8 minutes away, so I didn't have to sit around guessing.",
  },
  {
    name: "Farah Sheikh",
    location: "Gomti Nagar, Lucknow",
    rating: 4,
    text: "Plumber fixed a leak my building's regular guy missed twice. Upfront quote, no haggling. Would book again.",
  },
  {
    name: "Rohit Malhotra",
    location: "Sector 62, Noida",
    rating: 5,
    text: "Used RepairMithra for deep cleaning before a family visit. The team was on time and thorough. Easy 5 stars.",
  },
];

export const TRUST_STATS = [
  { label: "Verified technicians", value: 6200, suffix: "+" },
  { label: "Homes served", value: 480000, suffix: "+" },
  { label: "Cities covered", value: 42, suffix: "" },
  { label: "Average rating", value: 4.8, suffix: "/5" },
];
