/** @type {import('tailwindcss').Config} */
export default {
  content: ["./index.html", "./src/**/*.{js,jsx}"],
  theme: {
    extend: {
      colors: {
        ink: {
          DEFAULT: "#16213E",
          light: "#1F2D5C",
        },
        marigold: {
          DEFAULT: "#F4A623",
          dark: "#D98B0F",
          light: "#FCE3B0",
        },
        paper: "#FAF9F6",
        slate: {
          DEFAULT: "#5C6478",
        },
        trust: {
          DEFAULT: "#1F9D6F",
        },
      },
      fontFamily: {
        display: ["Sora", "sans-serif"],
        body: ["Inter", "sans-serif"],
      },
      boxShadow: {
        card: "0 4px 20px -4px rgba(22, 33, 62, 0.10)",
        "card-hover": "0 12px 32px -8px rgba(22, 33, 62, 0.20)",
      },
      borderRadius: {
        xl2: "1.25rem",
      },
      animation: {
        "pulse-ring": "pulse-ring 2s cubic-bezier(0.4, 0, 0.6, 1) infinite",
        float: "float 6s ease-in-out infinite",
      },
      keyframes: {
        "pulse-ring": {
          "0%, 100%": { opacity: "0.4", transform: "scale(1)" },
          "50%": { opacity: "0.15", transform: "scale(1.15)" },
        },
        float: {
          "0%, 100%": { transform: "translateY(0px)" },
          "50%": { transform: "translateY(-10px)" },
        },
      },
    },
  },
  plugins: [],
};
