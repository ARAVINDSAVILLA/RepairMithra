import express from "express";
import cors from "cors";
import dotenv from "dotenv";
import apiRoutes from "./routes/services.routes.js";
import { testConnection } from "./config/db.js";

dotenv.config();

const app = express();
const PORT = process.env.PORT || 5000;

app.use(cors({ origin: process.env.CLIENT_ORIGIN || "http://localhost:5173" }));
app.use(express.json());

app.get("/api/health", (req, res) => res.json({ status: "ok" }));
app.use("/api", apiRoutes);

// Fallback error handler
app.use((err, req, res, next) => {
  console.error(err.stack);
  res.status(500).json({ message: "Something went wrong on our end." });
});

app.listen(PORT, async () => {
  console.log(`🚀 RepairMithra API running on http://localhost:${PORT}`);
  await testConnection();
});
