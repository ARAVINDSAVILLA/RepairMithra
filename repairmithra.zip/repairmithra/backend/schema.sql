CREATE DATABASE IF NOT EXISTS repairmithra;
USE repairmithra;

CREATE TABLE IF NOT EXISTS services (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(100) NOT NULL,
  icon VARCHAR(50) NOT NULL,        -- lucide-react icon name
  jobs_completed VARCHAR(50) NOT NULL,
  starting_price VARCHAR(50) NOT NULL,
  sort_order INT DEFAULT 0
);

CREATE TABLE IF NOT EXISTS testimonials (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(100) NOT NULL,
  location VARCHAR(100) NOT NULL,
  rating TINYINT NOT NULL,
  review_text TEXT NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS bookings (
  id INT AUTO_INCREMENT PRIMARY KEY,
  service_id INT NOT NULL,
  customer_name VARCHAR(100) NOT NULL,
  phone VARCHAR(20) NOT NULL,
  address VARCHAR(255) NOT NULL,
  scheduled_for DATETIME NULL,
  status ENUM('requested', 'assigned', 'on_the_way', 'completed', 'cancelled') DEFAULT 'requested',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (service_id) REFERENCES services(id)
);

INSERT INTO services (name, icon, jobs_completed, starting_price, sort_order) VALUES
('Electrician', 'Zap', '38k+ jobs done', 'From ₹149', 1),
('Plumbing', 'Wrench', '52k+ jobs done', 'From ₹179', 2),
('AC Repair & Service', 'Wind', '26k+ jobs done', 'From ₹499', 3),
('Home Cleaning', 'Sparkles', '44k+ jobs done', 'From ₹399', 4),
('Carpentry', 'Hammer', '19k+ jobs done', 'From ₹199', 5),
('Painting', 'PaintRoller', '12k+ jobs done', 'From ₹15/sqft', 6),
('Appliance Repair', 'Refrigerator', '31k+ jobs done', 'From ₹249', 7),
('Pest Control', 'Bug', '9k+ jobs done', 'From ₹599', 8);

INSERT INTO testimonials (name, location, rating, review_text) VALUES
('Ananya Rao', 'Whitefield, Bengaluru', 5, 'Booked an AC service at 9pm and someone was at my door by 10am the next day.'),
('Vikram Sethi', 'Andheri, Mumbai', 5, 'The live tracking is what sold me — I could see the electrician was 8 minutes away.'),
('Farah Sheikh', 'Gomti Nagar, Lucknow', 4, 'Plumber fixed a leak my building''s regular guy missed twice. Upfront quote, no haggling.'),
('Rohit Malhotra', 'Sector 62, Noida', 5, 'Used RepairMithra for deep cleaning before a family visit. Easy 5 stars.');
