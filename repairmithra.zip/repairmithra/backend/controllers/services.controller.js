import { pool } from "../config/db.js";

// GET /api/services
export async function getServices(req, res) {
  try {
    const [rows] = await pool.query(
      "SELECT id, name, icon, jobs_completed AS jobs, starting_price AS price FROM services ORDER BY sort_order ASC"
    );
    res.json(rows);
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: "Unable to load services right now." });
  }
}

// GET /api/testimonials
export async function getTestimonials(req, res) {
  try {
    const [rows] = await pool.query(
      "SELECT name, location, rating, review_text AS text FROM testimonials ORDER BY created_at DESC LIMIT 12"
    );
    res.json(rows);
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: "Unable to load testimonials right now." });
  }
}

// POST /api/bookings
export async function createBooking(req, res) {
  const { serviceId, customerName, phone, address, scheduledFor } = req.body;

  if (!serviceId || !customerName || !phone || !address) {
    return res.status(400).json({ message: "serviceId, customerName, phone and address are required." });
  }

  try {
    const [result] = await pool.query(
      `INSERT INTO bookings (service_id, customer_name, phone, address, scheduled_for, status)
       VALUES (?, ?, ?, ?, ?, 'requested')`,
      [serviceId, customerName, phone, address, scheduledFor || null]
    );
    res.status(201).json({ bookingId: result.insertId, status: "requested" });
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: "Unable to create booking right now." });
  }
}
