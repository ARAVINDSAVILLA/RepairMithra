import { Router } from "express";
import { getServices, getTestimonials, createBooking } from "../controllers/services.controller.js";

const router = Router();

router.get("/services", getServices);
router.get("/testimonials", getTestimonials);
router.post("/bookings", createBooking);

export default router;
